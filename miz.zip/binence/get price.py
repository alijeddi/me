import requests
market = 'BTCUSDT'
url = 'https://fapi.binance.com/fapi/v1/premiumIndex?symbol=' + market
data = requests.get(url).json()
print(data["markPrice"])
#logshort ratio
url = 'https://fapi.binance.com/futures/data/globalLongShortAccountRatio?symbol=' + market+'&period=5m'
data = requests.get(url).json()
print(data)
# send order
symbol=marketname
side =
type = LIMIT
timestamp =
price=
url = 'https://fapi.binance.com//fapi/v1/order (HMAC SHA256)
