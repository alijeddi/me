import requests
import pandas as pd
import stock_pandas as pds
import urllib.request as req
import numpy as np
import indicator.MACD as MACD
import indicator.RSI as RSI
import indicator.VMA as VMA
import indicator.movigavrage as MA
import CHECKER as CHEKER
def loaddata():

    ##parameters................................
    numofdata=100
    market = 'BTCUSDT'
    tick_interval = '3m'
    #lists
    ol=[]
    cl=[]
    hl=[]
    ll=[]
    vl=[]
    colorbar=[]

    url = 'https://fapi.binance.com/fapi/v1/klines?symbol='+market+'&interval='+tick_interval#+'&limit='+str(numofdata)#+'&contractType=perpetual'

    print("data loading:")
    data = requests.get(url)
    print(data)
    data=data.json()
    d=data[-numofdata:]
    print("data loaded")
    for i in range(numofdata):
        Open=round(float(d[i][1]),2)
        High=round(float(d[i][2]),2)
        Low=round(float(d[i][3]),2)
        Close=round(float(d[i][4]),2)
        Volume=round(float(d[i][5]),5)
        if i ==0 :
            HA_Close = (Open + High + Low + Close) / 4
            HA_Open = (Open + Close) / 2
            HA_Low = Low
            HA_High = High
            ol.append(HA_Open)
            cl.append(HA_Close)
            hl.append(HA_High)
            ll.append(HA_Low)
            vl.append(Volume)
        else:
            HA_Close = (Open + High + Low + Close) / 4
            HA_Open = (ol[i-1] + cl[i-1]) / 2
            tmp=[Low, HA_Open, HA_Close]
            HA_Low = min(tmp)
            tmp=[High, HA_Open,  HA_Close]
            HA_High = max(tmp)
            ol.append(HA_Open)
            cl.append(HA_Close)
            hl.append(HA_High)
            ll.append(HA_Low)
            vl.append(Volume)

        if (HA_Close<HA_Open):
            colorbar.append('Red')
        else:
            colorbar.append('Green')
    collction=np.zeros([4,numofdata])
    collction[0,:]=ol
    collction[1,:]=hl
    collction[2,:]=ll
    collction[3,:]=cl
    alldata=collction



    #volume moving avrage
    vmaline=VMA.vma(vl,numofdata)

    #moving avrage
    maline=MA.ma(cl,numofdata)

    macdl,signall,histl,macdcolorsl=MACD.macd(cl)

    rsil=RSI.rsi(cl,14)


    print("start checking")
    state=CHEKER.cheker (cl,vl,colorbar,vmaline,maline,rsil,macdl,signall,histl)
    print("finished")
    print("state check"+ str (state))
    return state,cl[-1]
    #return numofdata,alldata,maline,vl,colorbar,vmaline,rsil,macdl,signall,histl,macdcolorsl
