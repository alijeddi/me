p=10

for i in range(50):
    p=p+(p*.20)

print(p)