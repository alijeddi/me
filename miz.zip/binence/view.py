import matplotlib.pyplot as plt
import numpy as np
import dataloader as dl

def drawing(data):
    numofdata,alldata,maline,vl,color,vmaline,rsil,macd,signal,hist,macdcolors=data

    #plt.ion()
    plt.figure(figsize=(16, 8))
    barsp=plt.subplot(511,title="chart")
    volumesp=plt.subplot(512,title="Volumes")
    enteryp=plt.subplot(513,title="signal")
    rsip=plt.subplot(514,title="RSI")
    time=np.arange(numofdata)
    time[:]+=1

    '''macd plot'''
    macdind = plt.subplot(515, title="macd")
    macdind.plot(time, macd, color='blue')
    macdind.plot(time, signal, color='orange')
    macdind.plot(time, hist,color='red')#,ls="dash" color=macdcolors)

    '''macd plot'''
    barplot = barsp.boxplot(alldata,vert=True,  patch_artist=True)
    barsp.plot(time,maline,color='Black')
    volumesp.bar(time, vl,color=color)
    volumesp.plot(time,vmaline)
    #enteryp.bar(time, buys, color=signs)

    volumesp.grid(b=True, which='major', color='#666666', linestyle='-')

    rsip.plot(time,rsil)


    for patch, color in zip(barplot['boxes'], color):
        patch.set_facecolor(color)
    plt.grid(b=True, which='major', color='#666666', linestyle='-')
    plt.minorticks_on()
    plt.grid(b=True, which='minor', color='#999999', linestyle='-', alpha=0.2)

    plt.show()
