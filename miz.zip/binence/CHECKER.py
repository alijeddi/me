import numpy as np


def cheker(cl, vl, colorbar, vmaline, maline, rsil, macdl, signall, histl):
    '''volume check'''
    overflag = 0
    redflag = 0

    sellbuy = 0
    if colorbar[-1] == 'Green':
        redcandels = colorbar[-5:-1]
        candles = vl[-5:-1]
        vmacandles = vmaline[-5:-1]
        if redcandels[-1] == "Red" and redcandels[-2] == "Red":
            redflag = 1
            for i in range(4):
                if candles[i] > vmacandles[i]:
                    overflag = 1

        macdl = np.array(macdl)
        macd = macdl[-1] + 1
        signall = np.array(signall)
        signal = signall[-1]
        histl = np.array(histl)
        hist = histl[-1]
        macdflag = 0

        if hist > macd and hist > signal:
            if hist > histl[-2]:
                macdflag = 1
            else:
                macdflag = 0
        elif hist < signal:
            if hist > histl[-2] and signal > macd:
                macdflag = 1
        cutmacd = 0
        if macd > signal and macdl[-2] < signall[-2]:
            cutmacd = 1

        rsiflag = 0
        rsil = np.array(rsil)
        if rsil[-1] > rsil[-2] and rsil[-1] > rsil[-3]:
            rsiflag = 1

        if macdflag and rsiflag and redflag:
            sellbuy = 1
        else:
            sellbuy = 0

    if colorbar[-1] == "Red":

        redvol = vl[-1]

        redvma = vmaline[-1]
        rsil = np.array(rsil)
        rsi = rsil[-1]
        macdl = np.array(macdl)
        macd = macdl[-1]
        maline = np.array(maline)
        ma = maline[-1]
        close = cl[-1]
        sellma=0
        sellrsi =0
        sellmacd =0
        sellvol =0
        if redvol > redvma:
            sellvol = 1

        if macd < macdl[-2]:
            sellmacd = 1

        if rsi < rsil[-2]:
            sellrsi = 1

        if ma > close:
            sellma = 1

        sellstate = sellma+sellrsi+sellmacd+sellvol
        if sellstate >= 3:
            sellbuy = 2
        else:
            sellbuy = 0

    return sellbuy
