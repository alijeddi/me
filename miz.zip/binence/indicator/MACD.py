import matplotlib.pyplot as plt
import stock_pandas as pds
import numpy as np
def macd(closes):

    stock = pds.StockDataFrame(closes, columns=['close'])
    ticker = stock.get_column('close')
    short = ticker.ewm(span=12, adjust=False).mean()
    long = ticker.ewm(span=26, adjust=False).mean()
    macd = short - long
    signal = macd.ewm(span=9, adjust=False).mean()
    hist=macd-signal
    macdcolors=[]
    macdcolors.append('red')
    for i in range(1,len(hist)):
        if hist[i]>=hist[i-1]:
            macdcolors.append('green')
        else:
            macdcolors.append('red')

    return macd,signal,hist,macdcolors

