def vma(vl,numofdata):
    vmaline = []
    lengh = 10
    sum = 0
    for i in range(lengh):
        for j in range(lengh):
            sum = sum + vl[i]
        sum = sum / lengh
        vmaline.append(sum)

    for i in range(lengh, numofdata):
        sum = 0
        for j in range(lengh):
            sum = sum + vl[i - j]
        sum = sum / lengh
        vmaline.append(sum)
    return vmaline