def ma(cl,numofdata):
    maline = []
    ma = 8
    sum = 0
    for i in range(ma):
        for j in range(ma):
            sum = sum + cl[i]
        sum = sum / (i + 0.00001)
        maline.append(cl[i])

    for i in range(ma, numofdata):
        sum = 0
        for j in range(ma):
            sum = sum + cl[i - j]
        sum = sum / ma
        maline.append(sum)
    return maline