import requests
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.ticker as mticker
import mpl_finance
from tensorflow.python.training.input import batch

market = 'BTCUSDT'
tick_interval = '5m'

cl=[]

url = 'https://api.binance.com/api/v3/klines?symbol='+market+'&interval='+tick_interval
data = requests.get(url).json()

print (data)

for i in range(500):
    x=int(float(data[i][4]))
    print(x)
    cl.append(x)

xtrain=[]
ytrain=[]
for i in range(len(cl)):
    xtrain.append(cl[i:i+20])
    ytrain.append(cl[i+20:i+25])
    if ytrain==len(cl):
        break

print("make data train")

import tensorflow.keras.layers as lyr
from tensorflow.keras.models import Sequential

model=Sequential()
model.add(lyr.Conv1D(20,3,activation='relu',input_shape=[None,20,1]))
model.add(lyr.Conv1D(20,5,activation='relu'))
model.add(lyr.Conv1D(20,3,activation='relu'))
#model.add(lyr.LSTM(10,activation='tanh'))
model.add(lyr.Flatten())
model.add(lyr.Dense(40,activation='relu'))
model.add(lyr.Dense(20,activation="relu"))
model.add(lyr.Dense(5,activation='softmax'))
model.summary()
xtrain=np.asarray(xtrain).astype(np.float32)
ytrain=np.asarray(ytrain).astype(np.float32)
xtrain=np.expand_dims(xtrain,-1)
ytrain=np.expand_dims(ytrain,-1)
model.compile(optimizer='adam',loss='mse',metrics=['accuracy'])

model.fit(xtrain,ytrain,batch_size=16,epochs=20,steps_per_epoch=16)
