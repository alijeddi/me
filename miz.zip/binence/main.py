import time
import view
import datetime as dt
import dataloader
while (1):
    sec = dt.datetime.utcnow().second
    if sec <3:
        print("enter to loop")
        break
    time.sleep(2)

while(1):
    buysellflag=0
    openposition=0
    min=dt.datetime.utcnow().minute
    sec=dt.datetime.utcnow().second
    if (min+1)%3==0 and sec >45 :
        print('enter 2:45')
        closes=0
        try:
            print("start checking")
            state,closes=dataloader.loaddata()
            print("finisht cheking")
            buysellflag=state
            
            print('checked')
        except:
        
            print('reject')
            
            

        if buysellflag==1:
            print(dt.datetime.utcnow())
            print("buuuuy it")
            print("open position")
            print(closes)
            openposition=1
            from datetime import datetime
            o=open("sign.txt",'a')
            o.writelines("open "+str(closes)+" | "+str(datetime.utcnow())+'\n')
            o.close()
            time.sleep(15)
        elif buysellflag==2 and openposition:
            print(dt.datetime.utcnow())
            print("close it")
            openposition=0
            print(closes)
            from datetime import datetime
            o=open("sign.txt",'a')
            o.writelines("close "+str(closes)+" | "+str(datetime.utcnow())+'\n')
            o.close()
            time.sleep(15)
        else:
            time.sleep(15)


    else:
        time.sleep(10)
        print(min)
        print("waiting for closing next candel")



